-- Adminer 4.8.1 MySQL 5.1.72-community dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `cv16`;
CREATE DATABASE `cv16` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `cv16`;

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `titulek` varchar(64) NOT NULL,
  `obsah` varchar(128) NOT NULL,
  `datum_pridani_clanku` datetime NOT NULL,
  `datum_publikace` datetime NOT NULL,
  `stav_clanku` bit(1) NOT NULL,
  `hodnoceni_clanku` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `posts` (`id`, `titulek`, `obsah`, `datum_pridani_clanku`, `datum_publikace`, `stav_clanku`, `hodnoceni_clanku`) VALUES
(1,	'Nejlepší ?lánek 01',	'Abc',	'2025-04-20 20:00:00',	'2026-04-20 20:00:00',	CONV('1', 2, 10) + 0,	3),
(2,	'Nejlepší ?lánek 02',	'Abbc',	'2030-10-20 22:00:00',	'2005-11-20 22:00:00',	CONV('0', 2, 10) + 0,	2),
(3,	'?lánek 3',	'aBBBc',	'2024-11-20 22:00:00',	'2025-11-20 22:00:00',	CONV('0', 2, 10) + 0,	3),
(4,	'?lánek 4',	'AbBbc',	'2028-02-20 22:00:00',	'2001-03-20 22:00:00',	CONV('1', 2, 10) + 0,	3);

-- 2023-01-11 07:20:21
