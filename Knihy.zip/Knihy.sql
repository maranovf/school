-- Adminer 4.8.1 MySQL 5.1.72-community dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `Knihy`;
CREATE DATABASE `knihy` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `Knihy`;

DROP TABLE IF EXISTS `ctenari`;
CREATE TABLE `ctenari` (
  `id` int(11) NOT NULL,
  `Jmeno` varchar(64) NOT NULL,
  `Mesto` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `ctenari` (`id`, `Jmeno`, `Mesto`) VALUES
(1,	'Jan',	'Praha'),
(2,	'Petr',	'Brno'),
(3,	'Marek',	'Praha');

DROP TABLE IF EXISTS `knihy`;
CREATE TABLE `knihy` (
  `id` int(11) NOT NULL,
  `jmeno` varchar(64) NOT NULL,
  `jmeno_autora` varchar(64) NOT NULL,
  `pocet_stran` int(11) NOT NULL,
  `zanr` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `knihy` (`id`, `jmeno`, `jmeno_autora`, `pocet_stran`, `zanr`) VALUES
(1,	'Robinson',	'Defoe',	51,	'Historický'),
(2,	'Harry Potter',	'Rowlingová',	29,	'Fantasy'),
(3,	'Revizor',	'Puškin',	18,	'Drama'),
(4,	'Došliminapady',	'Novotný',	85,	'Drama');

-- 2023-01-04 07:30:08
