-- Adminer 4.8.1 MySQL 5.1.72-community dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `studenti`;
CREATE TABLE `studenti` (
  `id` int(11) NOT NULL,
  `jmeno_prijmeni` varchar(128) NOT NULL,
  `trida` varchar(64) NOT NULL,
  `datum_narozeni` date NOT NULL,
  `adresa` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `studenti` (`id`, `jmeno_prijmeni`, `trida`, `datum_narozeni`, `adresa`) VALUES
(1,	'Bernard M',	'1. AB',	'2001-04-29',	'1 Roudnice'),
(2,	'Tomáš',	'2. AB',	'2002-09-26',	'2 Roudnice'),
(3,	'Ji?í Nový',	'1. AB',	'2004-03-26',	'1 Záluží'),
(4,	'Anna Nováková',	'1. A',	'2002-04-25',	'3 Roudnice'),
(5,	'Petr Carda',	'2. AB',	'1998-02-22',	'2 Záluží');

-- 2023-01-23 07:43:36
