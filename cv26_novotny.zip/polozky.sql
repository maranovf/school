-- Adminer 4.8.1 MySQL 5.1.72-community dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `polozky`;
CREATE TABLE `polozky` (
  `id` int(11) NOT NULL,
  `nazev_polozky` varchar(128) NOT NULL,
  `cena_kus` int(11) NOT NULL,
  `typ` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `polozky` (`id`, `nazev_polozky`, `cena_kus`, `typ`) VALUES
(1,	'Bageta',	60,	''),
(2,	'Sušenky',	10,	'');

-- 2023-03-27 06:55:24
