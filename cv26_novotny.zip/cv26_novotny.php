<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Přihlášení uživatele</title>
        <?php

        $db_host = "localhost";
        $db_user = "root";
        $db_pass = "root";
        $db_db = "cv26_novotny";

        $conn = new mysqli($db_host,$db_user,$db_pass,$db_db);
        if($conn->connect_errno){
            echo "Chyba při připojování k databázi.".$conn->connect_error;
            exit();
        }
        $conn->set_charset("utf8");

        $sql = "SELECT * FROM cv26_novotny";
        $result = $conn->query($sql);
        $datas = [];

        if($result){
            while($row = $result->fetch_assoc()){
                $datas[] = $row;
            }
        }
        ?>
    </head>
    <body>
    <form method="post">
        <table width="20%">
         <tr>
             <td>Název: <input type="text" name="jmeno" required><br></td>
</tr>
<tr>
    <td>
Vyberte typ: <select name="typ">
<option value=""><?php Europe/Prague; echo $row['nazev_polozky']; ?></option>
</select><br></td>
</tr>
<tr>
         <td>Cena za kus: <input type="text" name="email" required><br></td>
</tr>
<tr>
         <td><input type="submit" name="send" value="Odeslat"></td>
</tr>
</table>
     </form>
     <?php
     $result->free();
            ?>
            <ul>
                <?php foreach($datas as $datas):?>
                    <li><?php echo $datas['*'];?></li>
                <?php endforeach;?>    
            </ul>